// 等待页面和资源加载完成后执行
window.onload = function(){
    //调试代码
    // alert(1);

    var mySwiper = new Swiper('.swiper-container', {
        autoplay: true,//可选选项，自动滑动
        loop : true,//无缝轮播(当图片到最后一个的时候直接滑到第一个)
        pagination: {
            el: '.swiper-pagination',
        },
        
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        effect : 'cube',
        //自动播放
        autoplay:true,//等同于以下设置
        /*autoplay: {
            delay: 3000,
            stopOnLastSlide: false,
            disableOnInteraction: true,
        },*/
    });


    //当页面滚动超过一屏的距离
    // 获取也免得可视的宽高
    var ch = document.documentElement.clientHeight*4;
    console.log(document.documentElement.clientHeight);//页面高度
    //页面得滚动距离
    console.log(document.documentElement.scrollTop);
    //获取元素
    var goTop = document.getElementsByClassName('goTop')[0];//拿到元素得加上[0]
    console.log(goTop);
    //页面滚动事件
    window.onscroll = function(){
        //console.log(document.documentElement.scrollTop);
        if(document.documentElement.scrollTop > ch){    //隐藏icon-top
            goTop.style.display = 'block';
        }else{
            goTop.style.display = 'none';
        };
    };




    var timer = null;
    // 点击返回顶部按钮 让页面滚动会顶部
    goTop.onclick = function () {
        // 清除定时器
        clearInterval(timer);
        // document.documentElement.scrollTop = 0;
        timer = setInterval(function () {
            document.documentElement.scrollTop -= 50;
            if(document.documentElement.scrollTop <= 0){
                clearInterval(timer);
            }
        }, 10);
    };

    function getRTime(){
        var EndTime= new Date('2021/06/21 14:00:00'); //截止时间
        var NowTime = new Date();
        var t =EndTime.getTime() - NowTime.getTime();
         
        
        var h=Math.floor(t/1000/60/60%24);
        var m=Math.floor(t/1000/60%60);
        var s=Math.floor(t/1000%60);
         
        document.getElementById("th").innerHTML = h;
        document.getElementById("tm").innerHTML = m;
        document.getElementById("ts").innerHTML = s;
        }
        setInterval(getRTime,1000);

};